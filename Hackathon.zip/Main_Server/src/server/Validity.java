package server;

import com.account.User;

import java.io.*;
import java.util.Calendar;
import java.util.Date;

public class Validity {

    public static boolean validity(User user) throws IOException {
        Date expireDate = user.expireDate.getTime();
        Date currentTime = new Date();

        if(currentTime.after(expireDate))
        {
            if(user.lastCaseDate==null) {

                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.MINUTE, 1);

                user.caseCounter = user.caseCounter + 1;
                user.lastCaseDate = cal.getTime();

                FileOutputStream fout = new FileOutputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + user.carnumber);
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(fout);
                objectOutputStream.writeObject(user);
                return false;
            }

            else
            {
                Date date = new Date();

                if(date.after(user.lastCaseDate)) {

                    Calendar cal = Calendar.getInstance();
                    cal.add(Calendar.MINUTE, 1);

                    user.lastCaseDate = cal.getTime();
                    user.caseCounter = user.caseCounter + 1;

                    FileOutputStream fout = new FileOutputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + user.carnumber);
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(fout);
                    objectOutputStream.writeObject(user);
                    return false;
                }
            }

        }

        return true;
    }

}
