package com.account;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class User implements Serializable {

    public String name;
    public String email;
    public String password;
    public String carnumber;
    public Calendar expireDate;
    public Date lastCaseDate;
    public boolean hasComplain;
    public String complainMessage;
    public int caseCounter;

}
