package server;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class MailSender extends Thread {

    private String from = "billalhosainnirab10@gmail.com";
    private String password = "nirab458900";
    public String to = "";
    public String subject = "ROBO TRAFFIC";
    public String msg = "";

    public MailSender(String to, String msg)
    {
        this.to = to;
        this.msg = msg;
    }

    public void run() {
        send(from, password, to, subject, msg);
    }

    public void send(String from, String password, String to, String sub, String msg) {
        //Get properties object
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.socketFactory.port", "465");
        props.put("mail.smtp.socketFactory.class",
                "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", "587");
        //get Session
        Session session = Session.getDefaultInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(from, password);
                    }
                });
        //compose message
        try {
            MimeMessage message = new MimeMessage(session);
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject(sub);
            message.setContent(msg, "text/html");
            //send message
            Transport.send(message);
            System.out.println("message sent to " + to +  "successfully");
        } catch (MessagingException e) {
            System.out.println("message not sent");
            throw new RuntimeException(e);
        }

    }

}

