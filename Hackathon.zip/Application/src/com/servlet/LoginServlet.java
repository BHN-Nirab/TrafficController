package com.servlet;

import com.account.Account;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LoginServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

        String carnumber = request.getParameter("carnumber");
        String password = request.getParameter("password");

        Account acc = new Account();
        boolean isLogin = acc.login(carnumber, password);

        if(isLogin)
        {
            HttpSession session = request.getSession();
            response.sendRedirect("user.jsp");
            session.setAttribute("loginStatus", carnumber);
        }

        else
        {
            response.sendRedirect("index.jsp");
        }



    }

}
