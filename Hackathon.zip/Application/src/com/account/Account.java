package com.account;

import com.security.SHA_1;

import java.io.*;
import java.util.Calendar;
import java.util.Date;

public class Account {

    User user;

    public boolean createAccount(User user) throws IOException {
        if (user.name.isEmpty() || user.email.isEmpty() || user.carnumber.isEmpty() || user.password.isEmpty())
            return false;

        try {
            File folder = new File("E:\\Study Material\\Hackathon\\Application\\src\\resources\\");
            File listOfFile[] = folder.listFiles();

            for (File f : listOfFile) {
                if (f.isFile() && f.getName().contains(user.carnumber)) return false;
            }

        } catch (Exception e) {
        }

        user.password = SHA_1.encodeHex(user.password);
        user.hasComplain = false;
        user.caseCounter = 0;

        Calendar expireDate = Calendar.getInstance();
        expireDate.add(Calendar.MINUTE, 1);

        user.expireDate = expireDate;
        user.complainMessage = "";

        this.user = user;

        FileOutputStream fout = new FileOutputStream(new File("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + user.carnumber));
        ObjectOutputStream object = new ObjectOutputStream(fout);

        object.writeObject(this.user);

        return true;
    }

    public boolean login(String carnumber, String password) {

        try {
            FileInputStream fin = new FileInputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + carnumber);
            ObjectInputStream object = new ObjectInputStream(fin);
            User user = (User) object.readObject();

            if (user.carnumber.equals(carnumber) && user.password.equals(SHA_1.encodeHex(password)))
                return true;

            else
                return false;

        } catch (Exception e) {
            return false;
        }
    }
}
