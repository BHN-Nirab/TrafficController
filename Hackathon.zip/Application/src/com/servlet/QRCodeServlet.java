package com.servlet;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.security.RSAUtil;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import static com.security.RSAUtil.encrypt;

@WebServlet(name = "QRCodeServlet")
public class QRCodeServlet extends HttpServlet {

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

        String text = request.getParameter("text");
        response.setContentType("image/png");
        String encryptedString = "";
        try {
            encryptedString = Base64.getEncoder().encodeToString(encrypt(text, RSAUtil.publicKey));
        } catch (BadPaddingException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        try {
            getqr(encryptedString, 600, 600, "E:\\Study Material\\Hackathon\\Application\\src\\resources\\qrimages\\" + text + ".png");
        } catch (WriterException e) {
            e.printStackTrace();
        }

        File file = new File("E:\\Study Material\\Hackathon\\Application\\src\\resources\\qrimages\\" + text + ".png");
        FileInputStream fin = new FileInputStream(file);
        byte[] ara = new byte[(int) file.length()];

        fin.read(ara);

        ServletOutputStream servletOutputStream = response.getOutputStream();

        servletOutputStream.write(ara);
        servletOutputStream.flush();
        servletOutputStream.close();

    }

    private void getqr(String text, int height, int width, String filePath) throws WriterException, IOException {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        BitMatrix bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, width, height);

        Path path = FileSystems.getDefault().getPath(filePath);
        MatrixToImageWriter.writeToPath(bitMatrix, "PNG", path);
    }
}
