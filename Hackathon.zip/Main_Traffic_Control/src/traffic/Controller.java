package traffic;

import com.account.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;

import java.io.*;
import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    @FXML
    AnchorPane firstScreen;
    @FXML
    AnchorPane secondScreen;
    @FXML
    TextField carNumberSearch;
    @FXML
    Label carNumber;
    @FXML
    TextField name;
    @FXML
    TextField email;
    @FXML
    DatePicker expireDate;
    @FXML
    Label caseCounter;
    @FXML
    Button hasComplain;
    @FXML
    Label errormsg;

    User user = null;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        secondScreen.setVisible(false);
        firstScreen.setVisible(true);
        errormsg.setText("");
    }

    public void setCarNumberSearch(ActionEvent event) throws IOException, ClassNotFoundException {
        String carNumber = carNumberSearch.getText();

        if (!carNumber.isEmpty()) {
            File file = new File("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + carNumber);

            if (file.exists()) {

                FileInputStream fin = new FileInputStream(file);
                ObjectInputStream objectInputStream = new ObjectInputStream(fin);

                user = (User) objectInputStream.readObject();

                objectInputStream.close();
                fin.close();

                firstScreen.setVisible(false);
                secondScreen.setVisible(true);

                initializeUserInfo();

            }
            errormsg.setText("Invalid car number!");
        }

    }

    private void initializeUserInfo() {
        carNumber.setText(user.carnumber);
        name.setText(user.name);
        email.setText(user.email);
        caseCounter.setText(Integer.toString(user.caseCounter));
        Date date = user.expireDate.getTime();
        expireDate.setValue(date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());

        if (user.hasComplain) {
            hasComplain.setText("Mark as safe");
            hasComplain.setDisable(false);
        } else {
            hasComplain.setText("Wishing you to a safe journey");
            hasComplain.setDisable(true);
        }
    }

    public void setBack(ActionEvent event) {
        secondScreen.setVisible(false);
        firstScreen.setVisible(true);
        user = null;
        errormsg.setText("");
    }

    public void setName(ActionEvent event) {
        String tname = name.getText();
        if (!tname.isEmpty()) {
            try {
                FileOutputStream fout = new FileOutputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + carNumber.getText());
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(fout);

                user.name = tname;

                objectOutputStream.writeObject(user);
                objectOutputStream.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public void setEmail(ActionEvent event) {
        String temail = email.getText();
        if (!temail.isEmpty()) {
            try {
                FileOutputStream fout = new FileOutputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + carNumber.getText());
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(fout);

                user.email = temail;

                objectOutputStream.writeObject(user);
                objectOutputStream.close();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public void setCaseCounter(ActionEvent event) {

        try {
            FileOutputStream fout = new FileOutputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + carNumber.getText());
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fout);

            user.caseCounter = 0;
            user.lastCaseDate = null;

            objectOutputStream.writeObject(user);
            objectOutputStream.close();

            caseCounter.setText(Integer.toString(user.caseCounter));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void setHasComplain(ActionEvent event) {

        try {
            FileOutputStream fout = new FileOutputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + carNumber.getText());
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fout);

            user.hasComplain = false;
            user.complainMessage = "";

            objectOutputStream.writeObject(user);
            objectOutputStream.close();

            hasComplain.setText("Wishing you to a safe journey");
            hasComplain.setDisable(true);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void setExpireDate(ActionEvent event) {
        LocalDate localDate = expireDate.getValue();
        Date date = Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        try {
            FileOutputStream fout = new FileOutputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + carNumber.getText());
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fout);

            user.expireDate = cal;

            objectOutputStream.writeObject(user);
            objectOutputStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
