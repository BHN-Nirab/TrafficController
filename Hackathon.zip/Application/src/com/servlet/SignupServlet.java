package com.servlet;

import com.account.Account;
import com.account.User;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "Servlet")
public class SignupServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        User user = new User();
   
        user.name = request.getParameter("name");
        user.email = request.getParameter("email");
        user.password = request.getParameter("password");
        user.carnumber = request.getParameter("carnumber");

        Account acc = new Account();
        boolean isCreated = false;

        isCreated = acc.createAccount(user);

        if (isCreated) {
            HttpSession session = request.getSession();
            session.setAttribute("loginStatus", user.carnumber);
            response.sendRedirect("user.jsp");
        } else {
            response.sendRedirect("index.jsp");
        }

    }

}
