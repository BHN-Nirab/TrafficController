package traffic;

import com.github.sarxos.webcam.Webcam;
import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.concurrent.Task;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.util.Duration;

import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    private Webcam webCam = null;
    private BufferedImage grabbedImage;
    ObjectProperty<Image> imageProperty = new SimpleObjectProperty<Image>();

    @FXML
    ImageView frameHolder;
    @FXML
    Label name;
    @FXML
    Label email;
    @FXML
    Label carNumber;
    @FXML
    Label validity;
    @FXML
    Label caseNumber;
    @FXML
    Label complain;
    @FXML
    ImageView stopAlert;
    @FXML
    MediaView alertSound;
    @FXML
    Button stopBtn;

    boolean isPlaying;
    MediaPlayer mediaPlayer = null;
    Media media = null;



    int stop = 0;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        stopBtn.setVisible(false);

        Task<Void> webCamTask = new Task<Void>() {

            @Override
            protected Void call() throws Exception {


                webCam = Webcam.getWebcams().get(0);
                webCam.open();
                startWebCamStream();
                return null;
            }
        };

        Thread webCamThread = new Thread(webCamTask);
        webCamThread.setDaemon(true);
        webCamThread.start();

    }

    protected void startWebCamStream() {

        Task<Void> task = new Task<Void>() {


            @Override
            protected Void call() throws Exception {

                while (stop != 1) {
                    try {
                        if ((grabbedImage = webCam.getImage()) != null) {
                            Result result = null;
                            LuminanceSource source = new BufferedImageLuminanceSource(grabbedImage);
                            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
                            try {
                                result = new MultiFormatReader().decode(bitmap);
                            } catch (NotFoundException e) {
                            }


                            if (result != null) {
                                try{
                                String carnumber = result.getText();

                                String response = RequestHandler.sendData(carnumber);
                                String sub[] = response.split("~");

                                String res_name = sub[0];
                                String res_email = sub[1];
                                String res_carNumber = sub[2];
                                String res_date = sub[3];
                                String res_hasComplain = sub[4];
                                String res_complainmsg = sub[5];
                                String res_caseCounter = sub[6];
                                String res_hasValidity = sub[7];


                                Thread thread = new Thread(new Runnable() {

                                    @Override
                                    public void run() {
                                        Runnable updater = new Runnable() {

                                            @Override
                                            public void run() {
                                                name.setText(res_name);
                                                email.setText(res_email);
                                                carNumber.setText(res_carNumber);
                                                validity.setText(res_date);
                                                caseNumber.setText(res_caseCounter);
                                                complain.setText(res_complainmsg);

                                                if(res_hasValidity.equals("false") || res_hasComplain.equals("true"))
                                                {
                                                    stopBtn.setVisible(true);

                                                    if(!isPlaying) {

                                                    media = new Media(new File("E:\\Study Material\\Hackathon\\Traffic_Control\\src\\resources\\alert.wav").toURI().toString());
                                                    mediaPlayer = new MediaPlayer(media);
                                                    alertSound.setMediaPlayer(mediaPlayer);

                                                        isPlaying = true;
                                                        mediaPlayer.setOnReady(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                mediaPlayer.play();
                                                            }
                                                        });

                                                    }
                                                }
                                            }
                                        };


                                        try {
                                            Thread.sleep(100);
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }

                                        // UI update is run on the Application thread
                                        Platform.runLater(updater);

                                    }

                                });
                                // don't let thread prevent JVM shutdown
                                thread.setDaemon(true);
                                thread.start();

                                result = null;
                            }catch(Exception e){}
                            }

                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    final Image mainiamge = SwingFXUtils
                                            .toFXImage(grabbedImage, null);
                                    imageProperty.set(mainiamge);
                                }
                            });

                            grabbedImage.flush();

                        }
                    } catch (Exception e) {
                    } finally {

                    }

                }

                return null;

            }

        };
        Thread th = new Thread(task);
        th.setDaemon(true);
        th.start();
        frameHolder.imageProperty().bind(imageProperty);

    }

    public void setStopBtn(ActionEvent event)
    {
        mediaPlayer.stop();
        isPlaying = false;
        stopBtn.setVisible(false);
    }

}
