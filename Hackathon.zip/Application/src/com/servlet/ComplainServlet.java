package com.servlet;

import com.account.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

@WebServlet(name = "Servlet2")
public class ComplainServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String complainMessage = request.getParameter("complain");
        String carnumber = request.getParameter("carnumber");
        FileInputStream fin = new FileInputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + carnumber);
        User user = null;
        ObjectInputStream object = new ObjectInputStream(fin);
        try {
            user = (User) object.readObject();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        user.complainMessage = complainMessage;
        user.hasComplain = true;

        FileOutputStream fout = new FileOutputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + carnumber);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fout);
        objectOutputStream.writeObject(user);

        fin.close();
        fout.close();

        response.sendRedirect("user.jsp");

    }

}
