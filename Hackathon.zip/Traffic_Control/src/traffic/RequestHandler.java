package traffic;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class RequestHandler {
    public static String ip = "localhost";
    public static int port = 6767;

    public static Socket client;

    public static String sendData(String data)
    {
        try {
            client = new Socket(ip, port);

            ObjectOutputStream objectOutputStream = new ObjectOutputStream(client.getOutputStream());
            objectOutputStream.writeObject(data);

            ObjectInputStream objectInputStream = new ObjectInputStream(client.getInputStream());

            String response = (String) objectInputStream.readObject();

            client.close();
            return response;

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return "";
    }
}
