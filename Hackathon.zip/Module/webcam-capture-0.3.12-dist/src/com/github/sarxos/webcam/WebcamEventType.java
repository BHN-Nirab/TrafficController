package com.github.sarxos.webcam;

public enum WebcamEventType {

	OPEN,

	CLOSED,

	DISPOSED,

	NEW_IMAGE,

}
