package server;

import com.account.User;
import com.security.RSAUtil;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

public class Main {

    public static int port = 6767;


    public static void main(String[] args) throws InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException, NoSuchPaddingException {


        try {
            ServerSocket serverSocket = new ServerSocket(port);

            while (true)
            {
                System.out.println("Waiting for connection...");

                Socket client = serverSocket.accept();

                System.out.println("Connected with: " + client.getRemoteSocketAddress().toString());

                ObjectInputStream objectInputStream = new ObjectInputStream(client.getInputStream());

                String data = (String) objectInputStream.readObject();

                ObjectOutputStream objectOutputStream = new ObjectOutputStream(client.getOutputStream());
                String decryptedData = "";
                try {
                     decryptedData = RSAUtil.decrypt(data, RSAUtil.privateKey);
                }catch (Exception e){}

                try {


                    FileInputStream fin = new FileInputStream("E:\\Study Material\\Hackathon\\Application\\src\\resources\\" + decryptedData);
                    ObjectInputStream object = new ObjectInputStream(fin);

                    User user = (User) object.readObject();

                    Date date = user.expireDate.getTime();
                    boolean hasValidity = Validity.validity(user);
                    if (!hasValidity) user.caseCounter = user.caseCounter + 1;

                    if(!hasValidity)
                    {
                        String msg = "<h3>Hello " + user.name + ",</h3>" +
                                "Your licences is expired at " + user.expireDate.getTime().toString() +". Please renew your licences.<br>" +
                                "You are warned for " + user.caseCounter + " case.<br><br>" +
                                "<b>Thank you</b><br>" +
                                "<b>ROBO TRAFFIC</b>";
                        MailSender mailSender = new MailSender(user.email, msg);
                        mailSender.start();
                    }

                    if(user.hasComplain)
                    {
                        String msg = "<h3>Hello " + user.name + ",</h3>" +
                                "We are notifying to contact with us for your complain.<br>" +
                                "Your complain message is - <br><br>" +
                                "<u>" + user.complainMessage + "</u><br><br>" +
                                "Wishing you a safe journey.<b><br>" +
                                "<b>Thank you</b><br>" +
                                "<b>ROBO TRAFFIC</b>";
                        MailSender mailSender = new MailSender(user.email, msg);
                        mailSender.start();
                    }



                    String fileredString = user.name + "~" + user.email + "~" + user.carnumber + "~" + date.toString() + "~" + user.hasComplain + "~" + user.complainMessage + "~" + user.caseCounter + "~" + hasValidity;

                    objectOutputStream.writeObject(fileredString);
                }catch (Exception e)
                {}


            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }

}
